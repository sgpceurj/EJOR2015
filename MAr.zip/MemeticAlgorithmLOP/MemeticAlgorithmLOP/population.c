/*    
    MALOP Memetic Algorithm for Linear Ordering Problem
    Copyright (C) 2004  Tommaso Schiavinotto (tommaso.schiavinotto@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include "population.h"
#include "utilities.h"
#include "lop.h"

#define EMPTY_VAL (-1)

typedef struct _ma_heap_el {
  int mh_node;
  int mh_value;
} ma_heap_el_t;

static population_t Population[1];
static population_t PopTmp[1];
static population_t Offsprings[1];
static int FenotypeLength;
static long long int WorstFitness;

int DiversificationType;
int MaxGenNCAvg = MAXGEN_NOT_CHANGING_AVERAGE;
int MutationsRepeat;
int MutationType;
int CrossoverType;
int MaxMutLength;



ma_heap_el_t *maCreateHeap(int hl) {
    ma_heap_el_t *h;
    int i;

    h = (ma_heap_el_t *)malloc((hl+1)*sizeof(ma_heap_el_t));

    if ( !h ) fatal("maCreateHeap: Out of memory allocating heap.");
    for (i = 0; i <= hl; i++) h[i].mh_node = -1;
    return(h);
}

int maInsertHeap(ma_heap_el_t *h,  ma_heap_el_t *el, int hl) {
  int idx, p, r, ls, rs, c;
  ma_heap_el_t n;

  for (idx = 0; (idx < hl) && (h[idx].mh_node >= 0); idx++);
  /* idx is the index of a free cell,
     possibly the last one (always free) */
  /* If there is no free place, and the el is too far, 
     the el is not inserted */
  if ( ( idx == hl ) && 
       (h[0].mh_value <= el->mh_value) ) 
    return(-1);

  if ( idx < hl ) {
    h[idx].mh_node = el->mh_node;
    h[idx].mh_value = el->mh_value;
    
    for(r = 0; (idx >= 0) && (r == 0); idx = (idx - 1)/2) {
      p = (idx - 1) / 2;
      if ( h[p].mh_value < h[idx].mh_value ) {
	n = h[idx];
	h[idx] = h[p];
	h[p] = n;
      } else 
	r = p;
      /* because (0 - 1) / 2 == 0 */
      if (idx == 0) idx--;
    }
    /* if we always swapped (never set r), then the new el will be on the
       root, hence r = 0; */
    
    h[hl].mh_node = -1;
  } else {
    h[0].mh_node = el->mh_node;
    h[0].mh_value = el->mh_value; 
    r = -1;
    for (idx = 0; ( (2 * idx + 1) < hl ) && (r < 0); ) {
      ls = 2 * idx + 1;
      rs = 2 * idx + 2;
      if ( ( rs >= hl ) ) 
	c = ls;
      else 
	c = (h[ls].mh_value > h[rs].mh_value)?ls:rs;
      /* The element in idx is not in the right place */
      if ( h[c].mh_value > h[idx].mh_value ) {
	n = h[idx];
	h[idx] = h[c];
	h[c] = n;
	idx = c;
      } else 
	r = idx;
    }
    if (r < 0) r = idx;
  }
/*  printf ("H:");
  for (idx = 0; idx<hl; idx++) 
      printf(" %d", h[idx].mh_value);
      puts(""); */
  return r;
}



int maExtractHeap(ma_heap_el_t *h, int hl) {
  int r, ls, rs, c, i;

  r = h[0].mh_node;
  for (i = 0; ((2 * i + 1) < hl) && (h[i].mh_node >= 0); ) {
    ls = 2 * i + 1;
    rs = 2 * i + 2;
    if ( ( rs >= hl ) ) 
      c = ls;
    else 
      c = (h[ls].mh_value > h[rs].mh_value)?ls:rs;
    h[i] = h[c];
    i = c;
  }

  h[i].mh_node = -1;
  h[i].mh_value = -1;

/*  printf ("E:");
  for (i = 0; i<hl; i++) 
      printf(" %d", h[i].mh_value);
  puts("");
  printf("r: %d\n", r); */
  return(r);
}

individual_t extractIndividual(population_t *pop) {
  int ls, rs, c, i, hl;
  individual_t r, *h;

  h = pop->p_pop;
  hl = pop->p_size;
  r = h[0];
  /* if ( r.i_fenotype == NULL) return(r); */
  for (i = 0; ((2 * i + 1) < hl) && (h[i].i_fenotype); ) {
    ls = 2 * i + 1;
    rs = 2 * i + 2;

    if ( (rs >= hl) || !h[rs].i_fenotype ) {
	if ( !h[ls].i_fenotype ) break; /* both sons are null */
	else c = ls;  
    } else if ( h[ls].i_fenotype == NULL ) { /* only left son is null */
	c = rs;
    } else /* both sons are valid */
      c = (h[ls].i_fitness > h[rs].i_fitness)?ls:rs;
    h[i] = h[c];
    i = c;
  }

  
  h[i].i_fenotype = NULL;
  h[i].i_fitness = EMPTY_VAL;
  return(r);
}

int insertIndividual(population_t *pop, long int *fenotype, long long int fitness) {
  int idx, p, r, hl;
  individual_t n, el[1], *h;
  
  el->i_fenotype = fenotype;
  el->i_fitness = fitness;
  h = pop->p_pop;
  hl = pop->p_size;
  for (idx = 0; (idx < hl) && h[idx].i_fenotype; idx++);
  /* idx is the index of a free cell,
     possibly the last one (always free) */
  /* If there is no free place, and the el is too far, 
     the el is not inserted */
  if ( ( idx == hl ) && 
       (h[0].i_fitness <= el->i_fitness) ) 
       return(EMPTY_VAL); 

  h[idx].i_fenotype = el->i_fenotype;
  h[idx].i_fitness = el->i_fitness;
  
  for(r = 0; (idx >= 0) && (r == 0); idx = (idx - 1)/2) {
      p = (idx - 1) / 2;
      if ( h[p].i_fitness < h[idx].i_fitness ) {
	  n = h[idx];
	  h[idx] = h[p];
	  h[p] = n;
      } else 
	  r = p;
      /* because (0 - 1) / 2 == 0 */
      if (idx == 0) idx--;
  }
  /* if we always swapped (never set r), then the new el will be on the
     root, hence r = 0; */
  
  h[hl].i_fenotype = NULL;
  h[hl].i_fitness = EMPTY_VAL;
  
  return r;
}


void createPopulation(population_t *pop, int size) {
    int  i;

    /* Allocation of structure for the Population, and offsprings */
    pop->p_pop = (individual_t *)calloc(size+1, sizeof(individual_t));
    pop->p_size = size;
    for (i = 0; i <= size; i++) {
	pop->p_pop[i].i_fenotype = NULL;
	pop->p_pop[i].i_fitness = EMPTY_VAL;
    }

}

void printPopulation() {
  int i;

  for (i = 0; i < Population->p_size; i++) {
    //	Population->p_pop[i].i_fenotype = NULL;
    printf("%d: %Ld\n",i, Population->p_pop[i].i_fitness);
  }

}

void initializePopStructs(int fenlen, int size, int ncrossover, int nmutations, int mnc) {
    FenotypeLength = fenlen;
    createPopulation(Population, size);
    createPopulation(PopTmp, size);
    createPopulation(Offsprings, ncrossover + nmutations);
    MaxGenNCAvg = mnc;
}

int equalFenotype(long int *f1, long int *f2, int size) { 
    int j;
    for (j = 0; (j < size) && (f1[j] == f2[j]); j++);
    return(size == j);
}

void printFenotype(long int *f1, int size) { 
    int j;
    for (j = 0; (j < size); j++) printf(" %2ld", f1[j]);
}


void PrintArray (long * array, int length)
{
    int i=0;
	for (i=0;i<length;i++){
        
		printf(" %ld ",array[i]);
	}
    printf("\n");
}

void generateIndividuals() {
    int i, j;
    long long int c;
    long int *r;

    for (i = 0; i < Population->p_size;)
    {

        r = generate_random_vector(FenotypeLength);
        c = computeCost(r);
        //printf("%ld:\n ",c);
        localSearch(r, &c);
        for (j = 0; (j < i) && ( (c != Population->p_pop[j].i_fitness) || !equalFenotype(r, Population->p_pop[j].i_fenotype, FenotypeLength) ); j++);
        if ( j < i )
        {
            free(r);
        }
        else
        {
            i++;
            //printf("%d\n",i);
            insertIndividual(Population, r, c);
            if ( (WorstFitness < 0) || (c < WorstFitness) )
                WorstFitness = c;
        } 
    }
}

int resetPopulation(population_t *pop, int freefen) {
    int i,r;

    r=0;
    for (i = 0; i <= pop->p_size; i++) 
	if (pop->p_pop[i].i_fenotype) {
	    if (freefen) { 
		r++;
		free(pop->p_pop[i].i_fenotype);
	    }
	    pop->p_pop[i].i_fenotype = NULL;
	    pop->p_pop[i].i_fitness = EMPTY_VAL;
	}
    return(r);
}


void commitGenocide() {
    resetPopulation(Population,TRUE);
    resetPopulation(PopTmp,TRUE);
    resetPopulation(Offsprings,TRUE);
}

individual_t *bestIndividual(population_t *pop) {
    return(pop->p_pop);
}


void selectPopulation() {
    int i, j, size, offsize,  lstinserted;
    long int *fenotype;
    long long int fitness;
    individual_t extrfrompop, extrfromoff;
    population_t ptmp;
    int visitedo, visitedp, r, rp1, rp2;
    /*printf("***BEFORE SELECT***\nPOP P:\n");

    for (j = 0; j < Population->p_size; j++) {
	printf("%d(%p) ", Population->p_pop[j].i_fitness, Population->p_pop[j].i_fenotype );
	printFenotype(Population->p_pop[j].i_fenotype, FenotypeLength);
	puts("");
	}
    
    printf("\nPOP PT: ");
    for (j = 0; j < PopTmp->p_size; j++) {
	printf("%d(%p) ", PopTmp->p_pop[j].i_fitness, PopTmp->p_pop[j].i_fenotype );
	}
	printf("\nPOP O:\n"); 
    for (j = 0; j < Offsprings->p_size; j++) {
	printf("%d(%p) ", Offsprings->p_pop[j].i_fitness, Offsprings->p_pop[j].i_fenotype );
	printFenotype(Offsprings->p_pop[j].i_fenotype, FenotypeLength); 
	puts("");

    }
    printf("\n***BEFORE SELECT***\n***SELECT***\n"); */

    size = Population->p_size;
    offsize = Offsprings->p_size;
    
    extrfrompop.i_fenotype = NULL;
    extrfromoff.i_fenotype = NULL;


    /* lstinserted = 0;
    for (j = 0; j < Population->p_size; j++) 
	for (i = j+1; i < Population->p_size; i++) 
	    if ( equalFenotype(Population->p_pop[i].i_fenotype,
			       Population->p_pop[j].i_fenotype, FenotypeLength) ) 
		lstinserted++;

    printf("Population [%d]:", lstinserted);
    for (j = 0; j < Population->p_size; j++) 
	printf(" %p(%d)", Population->p_pop[j].i_fenotype, Population->p_pop[j].i_fitness);
    puts("");
    lstinserted = 0;

    for (j = 0; j < Offsprings->p_size; j++) 
	for (i = j+1; i < Offsprings->p_size; i++) 
	    if ( equalFenotype(Offsprings->p_pop[i].i_fenotype,
			       Offsprings->p_pop[j].i_fenotype, FenotypeLength) ) 
		lstinserted++;

    printf("OffSprings [%d]:", lstinserted);
    for (j = 0; j < Offsprings->p_size; j++) 
	printf(" %p(%d)", Offsprings->p_pop[j].i_fenotype, Offsprings->p_pop[j].i_fitness);
    puts("\n************************************");
    */
    visitedp = visitedo = 0;
    r=0;
    for (i = 0; i < size;) { /* i is incremented only whether a the element is inserted */
	lstinserted = FALSE;
	if ( !extrfrompop.i_fenotype ) {
	    extrfrompop = extractIndividual(Population);
	    if ( extrfrompop.i_fenotype ) visitedp++;
//	    printf("P: %p\n", extrfrompop.i_fenotype);
	}
	if ( !extrfromoff.i_fenotype ) {
	    extrfromoff = extractIndividual(Offsprings);
	    if ( extrfromoff.i_fenotype ) visitedo++;


//	    printf("O: %p\n", extrfromoff.i_fenotype);
	}

	if ( ( extrfromoff.i_fenotype ) ) {
	    if ( ( extrfromoff.i_fitness == extrfrompop.i_fitness ) ) { 
		fitness  = extrfrompop.i_fitness;
		fenotype = extrfrompop.i_fenotype;		

		/* check for the same fenotype */
		if (equalFenotype(extrfrompop.i_fenotype,extrfromoff.i_fenotype,FenotypeLength)) {
		    /*printf("EqualFenotype!!! (%p, %p)\n", extrfrompop.i_fenotype, extrfromoff.i_fenotype); */
		    /* Same fenotype, we free the double fenotype */
//		    printf("F1: %p\n", extrfromoff. i_fenotype);
		    free(extrfromoff. i_fenotype);
		    r++;
		    extrfromoff.i_fenotype = NULL;
		} /* Different fenotype, we consider the offspring individual in next iteration */
		/* extract from Population on the next iteration */
		extrfrompop.i_fenotype = NULL;
	    } else if (	extrfromoff.i_fitness > extrfrompop.i_fitness ) {
		fitness = extrfromoff.i_fitness;
		fenotype = extrfromoff.i_fenotype;
		/* extract from Offspring on the next iteration */
		extrfromoff.i_fenotype = NULL;
	    } else {
		fitness  = extrfrompop.i_fitness;
		fenotype = extrfrompop.i_fenotype;		
		/* extract from Population on the next iteration */
		extrfrompop.i_fenotype = NULL;
	    }		
	} else if (extrfrompop.i_fenotype) {
	    /* the individual extracted from the population is always valid */
	    fitness  = extrfrompop.i_fitness;
	    fenotype = extrfrompop.i_fenotype;		
	    /* extract from Population on the next iteration */
	    extrfrompop.i_fenotype = NULL;
	} else {
	    fitness = EMPTY_VAL;
	    fenotype = NULL;
	    fatal("Empty Individual in Population.");
	}
	if ( (!PopTmp->p_pop[0].i_fenotype) ) {
		if (!fenotype)
		    fatal("Wrong Insertion");
	    insertIndividual(PopTmp, fenotype, fitness);
	    WorstFitness=fitness;
	    i++;
	} else {
	    if (!fenotype)
		fatal("Wrong Insertion");
	    for (j = 0; j < PopTmp->p_size; j++) 
		if ( PopTmp->p_pop[j].i_fenotype && 
		     ( PopTmp->p_pop[j].i_fitness == fitness ) &&
		     equalFenotype(fenotype, PopTmp->p_pop[j].i_fenotype, FenotypeLength) ) break;
	    if ( j == PopTmp->p_size ) {
		insertIndividual(PopTmp, fenotype, fitness);
		WorstFitness=fitness;
		i++;
	    } else {
		lstinserted = TRUE;
		r++;
//		printf("F2: %p\n", fenotype);
		free(fenotype);
	    }
	}
	/*
	printf("[%d]Population:", i);
	for (j = 0; j < Population->p_size; j++) 
	    printf(" %p(%d)", Population->p_pop[j].i_fenotype, Population->p_pop[j].i_fitness);
	puts("");
	
	printf("[%d]OffSprings:", i);
	for (j = 0; j < Offsprings->p_size; j++) 
	    printf(" %p(%d)", Offsprings->p_pop[j].i_fenotype, Offsprings->p_pop[j].i_fitness);
	puts("");
	
	printf("[%d]PopTmp [%p(%d)] (%i):", i, fenotype, fitness, lstinserted);
	for (j = 0; j < PopTmp->p_size; j++) 
	    printf(" %p(%d)", PopTmp->p_pop[j].i_fenotype, PopTmp->p_pop[j].i_fitness);
	    puts(""); */
    }

    if ( extrfrompop.i_fenotype ) {
	r++;
//	printf("FP: %p\n", extrfrompop. i_fenotype);
	free(extrfrompop.i_fenotype);
    }

    if ( extrfromoff.i_fenotype ) {
	r++;
//	printf("FO: %p\n", extrfromoff. i_fenotype);
	free(extrfromoff.i_fenotype);
    }

    /* Now PopTmp contain the selected new population */
    ptmp = *PopTmp;
    *PopTmp = *Population;
    *Population = ptmp;
    
    rp1 = resetPopulation(Offsprings, TRUE);
    rp2 = resetPopulation(PopTmp, TRUE);
    
//    printf("Tot Freed: %d (%d+%d+%d)\n", r+rp1+rp2, r, rp1, rp2);
//    printf("Visited: %d (%d+%d)\n", visitedp+visitedo, visitedp, visitedo);
    /* lstinserted = 0;
    for (j = 0; j < Population->p_size; j++) 
	for (i = j+1; i < Population->p_size; i++) 
	    if ( equalFenotype(Population->p_pop[i].i_fenotype,
			       Population->p_pop[j].i_fenotype, FenotypeLength) ) 
		lstinserted++;
    printf("AFTER SELECT Population [%d]!\n", lstinserted);
    if (lstinserted > 0 ) exit(-1);
    */
    /*printf("\n***AFTER SELECT***\nPOP P: ");

    for (j = 0; j < Population->p_size; j++) {
	printf("%d(%p)\n", Population->p_pop[j].i_fitness, Population->p_pop[j].i_fenotype );
	 printFenotype(Population->p_pop[j].i_fenotype, FenotypeLength);
	   puts(""); 
    }

    printf("\nPOP PT: ");
    for (j = 0; j < PopTmp->p_size; j++) {
	printf("%d(%p) ", PopTmp->p_pop[j].i_fitness, PopTmp->p_pop[j].i_fenotype );
    }
    printf("\nPOP O: ");
    for (j = 0; j < Offsprings->p_size; j++) {
	printf("%d(%p) ", Offsprings->p_pop[j].i_fitness, Offsprings->p_pop[j].i_fenotype );
	} 
	printf("\n"); */
}

individual_t crossoverOB(population_t *pop, individual_t *mother, individual_t *father) {
    individual_t s, *son;
    long int fk, k, i, *motherpos;
    char *chosenpos;
    ma_heap_el_t *heap;

    motherpos = (long int *)calloc(FenotypeLength, sizeof(long int));
    son = &s;
    son->i_fenotype = (long int *)calloc(FenotypeLength, sizeof(long int));

    for (i = 0; i < FenotypeLength; i++) {
	motherpos[mother->i_fenotype[i]] = i;
	son->i_fenotype[i] = father->i_fenotype[i];
    }

    fk=2+rand0N(FenotypeLength-3);    
    chosenpos = (char *)malloc(FenotypeLength*sizeof(char));
    memset(chosenpos, 0, FenotypeLength*sizeof(char));
    
    k=0;
    for (i = 0; i < fk; i++) {

	int c;

	c = rand0N(FenotypeLength);
	if (!chosenpos[c]) {
	    chosenpos[c] = TRUE;
	    k++;
	}
    }
    heap = maCreateHeap(k);
    for (i = 0; i < FenotypeLength; i++) {
	ma_heap_el_t heapel;
	    /* The effective changed elements is smaller than k */
	if (chosenpos[i]) {
	    /* To sort the chosen elements using the position on the mother
	       fenotype */
	    heapel.mh_value = FenotypeLength - motherpos[son->i_fenotype[i]];
	    heapel.mh_node = son->i_fenotype[i];
	    maInsertHeap(heap, &heapel, k);
	}
    }
/*    printf("********************************************************************\n");
      printf("Chosen(%10d): ", k); */
    for (i = 0; i < FenotypeLength; i++) {
	int c;
	/* the chosen positions are scanned in order,
	   everytime one of them is met the best classified of the remaining
	   is chosen to be put on that position */
	if (chosenpos[i]) {
//	    printf(" X ");
	    c = maExtractHeap(heap, k);	    
	    son->i_fenotype[i] = c;
	}
/*	  else {
	    printf("   ");
	    }*/
    }
    free(heap);
    free(chosenpos);
    free(motherpos);

    son->i_fitness = computeCost(son->i_fenotype);
/*    puts("");
    printf("Father(%10Ld):", father->i_fitness);
    printFenotype(father->i_fenotype, FenotypeLength);
    puts(""); 

    printf("Mother(%10Ld):", mother->i_fitness);
    printFenotype(mother->i_fenotype, FenotypeLength);
    puts(""); 

    printf("Son   (%10Ld):", son->i_fitness);
    printFenotype(son->i_fenotype, FenotypeLength);
    puts(""); 
*/

    
    return(s);    
}

individual_t crossoverRanking(population_t *pop, individual_t *mother, individual_t *father) {
    individual_t s, *son;
    long int i, *motherpos, *fatherpos;
    ma_heap_el_t *heap;

    motherpos = (long int *)calloc(FenotypeLength, sizeof(long int));
    fatherpos = (long int *)calloc(FenotypeLength, sizeof(long int));
    son = &s;
    son->i_fenotype = (long int *)calloc(FenotypeLength, sizeof(long int));

    for (i = 0; i < FenotypeLength; i++) {
	motherpos[mother->i_fenotype[i]] = i;
	fatherpos[mother->i_fenotype[i]] = i;
    }

    heap = maCreateHeap(FenotypeLength);

    for (i = 0; i < FenotypeLength; i++) {
	ma_heap_el_t heapel;

	heapel.mh_value = FenotypeLength*2-(i + motherpos[father->i_fenotype[i]]);
	heapel.mh_node = father->i_fenotype[i];
//	printf("Inserting: %d, %d\n", heapel.mh_node, heapel.mh_value);
	maInsertHeap(heap, &heapel, FenotypeLength);
    }

    for (i = 0; i < FenotypeLength; i++) {
	/* the chosen positions are scanned in order,
	   everytime one of them is met the best classified of the remaining
	   is chosen to be put on that position */
	son->i_fenotype[i] = maExtractHeap(heap, FenotypeLength);	    
    }
    free(heap);

    son->i_fitness = computeCost(son->i_fenotype);

/*    printf("********************************************************************\n");
    printf("Father(%Ld):", father->i_fitness);
    printFenotype(father->i_fenotype, FenotypeLength);
    puts(""); 

    printf("Mother(%Ld):", mother->i_fitness);
    printFenotype(mother->i_fenotype, FenotypeLength);
    puts(""); 

    printf("Son(%Ld):", son->i_fitness);
    printFenotype(son->i_fenotype, FenotypeLength);
    puts(""); */


    return(s);    
}
 
individual_t crossoverCX(population_t *pop, individual_t *mother, individual_t *father) {
    individual_t s, *son;
    long int i, si, vi, *parentspos[2];
    long int *parentfen[2];

#define MOTHER 0
#define FATHER 1
    
    parentspos[MOTHER] = (long int *)calloc(FenotypeLength, sizeof(long int));
    parentspos[FATHER] = (long int *)calloc(FenotypeLength, sizeof(long int));
    parentfen[MOTHER] = mother->i_fenotype;
    parentfen[FATHER] = father->i_fenotype;
    son = &s;
    son->i_fenotype = (long int *)calloc(FenotypeLength, sizeof(long int));
    for (i = 0; i < FenotypeLength; i++) {
	parentspos[MOTHER][mother->i_fenotype[i]] = i;
	parentspos[FATHER][father->i_fenotype[i]] = i;
	if (mother->i_fenotype[i] == father->i_fenotype[i]) 
	    son->i_fenotype[i] = father->i_fenotype[i];
	else son->i_fenotype[i] = EMPTY_VAL;

	/* printf("[%d](%d+%d)->%d\n", i, mother->i_fenotype[i], father->i_fenotype[i], son->i_fenotype[i]); */
    }
    si = rand0N(FenotypeLength);
    /* printf("Starting from: %d", si); */
    for (vi = si; vi  < si+FenotypeLength; vi++) {
	i = vi%FenotypeLength;
	if ( son->i_fenotype[i] < 0 ) {
	    int j, p, k;
	    p = rand0N(2);
	    j = i;
	    /* printf(" %d", j);*/
	    do {
		son->i_fenotype[j] = parentfen[p][j];
		k = parentfen[(p+1)%2][j];
		j = parentspos[p][k];
	    } while ( j != i );
	} 
    }
    /*for (i = 0; (i < FenotypeLength) && (son->i_fenotype[i] >= 0); i++);
    if (i < FenotypeLength) {
	printf("\nFather: ");
	printFenotype(parentfen[FATHER], FenotypeLength);
	printf("\nMother: ");
	printFenotype(parentfen[MOTHER], FenotypeLength);
	printf("\nSon:    ");
	printFenotype(son->i_fenotype, FenotypeLength);
	printf("\n");
	fatal("AAAAAHHHH!!");
	}*/
    son->i_fitness = computeCost(son->i_fenotype);
    free(parentspos[MOTHER]);
    free(parentspos[FATHER]);
    return(s);    
}

individual_t crossoverDPX(population_t *pop, individual_t *mother, individual_t *father) {
    individual_t s, *son;
    int i, p;
    unsigned char *put;
    
    /* printf("DPX!!\n"); */
    put = (unsigned char *)calloc(FenotypeLength, sizeof(char));
    memset(put, 0, FenotypeLength);
    son = &s;
    son->i_fenotype = (long int *)calloc(FenotypeLength, sizeof(long int));
    for (i = 0; i < FenotypeLength; i++) {
	if (mother->i_fenotype[i] == father->i_fenotype[i]) {
	    son->i_fenotype[i] = father->i_fenotype[i];
	    put[son->i_fenotype[i]] = TRUE;
	} else {
	    son->i_fenotype[i] = EMPTY_VAL;
	}
	/* printf("[%d](%d+%d)->%d\n", i, mother->i_fenotype[i], father->i_fenotype[i], son->i_fenotype[i]); */
    }
    for (i = 0; i < FenotypeLength; i++) 
	if ( !put[i] ) {
	    p = rand0N(FenotypeLength);
	    for (p = rand0N(FenotypeLength); 
		 (son->i_fenotype[p] >= 0);
		 /*( mother->i_fenotype[p] == i ) ||
		   ( father->i_fenotype[p] == i ); */
		 p = (p + 1)%FenotypeLength );
	    son->i_fenotype[p] = i;
	} 
    son->i_fitness = computeCost(son->i_fenotype);
    free(put);
    return(s);
}

individual_t crossoverIndividuals(population_t *pop, individual_t *mother, individual_t *father) {
    switch (CrossoverType) {
	case 'd': return(crossoverDPX(pop, mother, father));
	case 'o': return(crossoverOB(pop, mother, father));
	case 'r': return(crossoverRanking(pop, mother, father));
	case 'c': return(crossoverCX(pop, mother, father));
	default: fatal("Unknown Crossover Type");
		exit(-1); /* Should never be reached */
    }
}


void doCrossovers(int ncrossover) {
    int i, j, k;
    individual_t o;

    /* printf("CS:-----"); */
    for (i = 0; i < ncrossover; i++ ) {
	j = rand0N(Population->p_size);
	do { k = rand0N(Population->p_size); } while (j == k);
	/* printf("\nI: %d (%d,%d)\n", i, j, k);  */
	o = crossoverIndividuals(Population, &(Population->p_pop[k]), &(Population->p_pop[j]));
	/* printFenotype(o.i_fenotype, FenotypeLength);  */
	localSearch(o.i_fenotype, &(o.i_fitness));
	/* printf("\n%d(%p) []", o.i_fitness, o.i_fenotype ); */
	insertIndividual(Offsprings, o.i_fenotype, o.i_fitness);
    } 
    /*printf("\nC: "); 
    for (i = 0; i < Offsprings->p_size; i++) {
	printf("%d(%p) ", Offsprings->p_pop[i].i_fitness, Offsprings->p_pop[i].i_fenotype );
    }
    puts(""); */

}

individual_t mutateByInterchange(individual_t *ind, int create) {
    int w, wp, v, j, n1, n2, min, max, g;
    individual_t ret;
    long int *lo;
    
    if ( create ){
	lo = (long int *)calloc(FenotypeLength, sizeof(long int));
	for ( j = 0; j < FenotypeLength; j++ )
	    lo[j] = ind->i_fenotype[j];
    } else {
	lo = ind->i_fenotype;
    }
    ret.i_fenotype = lo;
    ret.i_fitness = ind->i_fitness;
    /* printf("Mx%d", MutationsRepeat); */
    for (v = 0; v < MutationsRepeat; v++) {
	n1 = rand0N(FenotypeLength);
	/* Possible window of choice for values > CurrentIdx */
	w = ((FenotypeLength-n1) < MaxMutLength)?(FenotypeLength-n1):MaxMutLength;
	/* Possible window of choice for values < CurrentIdx */
	wp = (n1 < MaxMutLength)?n1:MaxMutLength;
	do {
	    n2 = n1 - wp + (int)rand0N(w+wp);
	    if ( n2 >= FenotypeLength ) n2 = FenotypeLength - 1;	    
	} while ( n1 == n2 );
	min = (n1 > n2)?n2:n1;
	max = (n1 > n2)?n1:n2;
	/* printf("Mutating: %d %d\n", min, max); */
	for ( g = 0, j = min + 1; j <= max; j++) 
	    g += CostMat[lo[j]][lo[min]] - CostMat[lo[min]][lo[j]];
	
	for ( j = min + 1; j < max; j++) 
	    g += CostMat[lo[max]][lo[j]] - CostMat[lo[j]][lo[max]];
	ret.i_fitness = ret.i_fitness + g;

	if (!create) ind->i_fitness += g;

    }

    return(ret);

}

individual_t mutateByInsert(individual_t *ind, int create) {
    int  w, wp, v, j, t, k, g;
    int CurrentIdx;
    long int *lo;
    individual_t ret;
    
    if ( create ){
	lo = (long int *)calloc(FenotypeLength, sizeof(long int));
	for ( j = 0; j < FenotypeLength; j++ )
	    lo[j] = ind->i_fenotype[j];

    } else {
	lo = ind->i_fenotype;
    }
    
    ret.i_fenotype = lo;
    ret.i_fitness = ind->i_fitness;


    for (v = 0; v < MutationsRepeat; v++) {
	CurrentIdx = rand0N(FenotypeLength);
	/* Possible window of choice for values > CurrentIdx */
	w = ((FenotypeLength-CurrentIdx) < MaxMutLength)?(FenotypeLength-CurrentIdx):MaxMutLength;
	/* Possible window of choice for values < CurrentIdx */
	wp = (CurrentIdx < MaxMutLength)?CurrentIdx:MaxMutLength;
	do {
	    j = CurrentIdx - wp + (int)rand0N(w+wp);
	    if ( j >= FenotypeLength ) j = FenotypeLength - 1;	    
	} while ( CurrentIdx == j );
	/* printf("Mutating: %d %d\n", CurrentIdx, j); */
	if ( j < CurrentIdx ) {
	    for (g = 0, k = j; k < CurrentIdx; k++)
		g += CostMat[lo[CurrentIdx]][lo[k]] - 
		    CostMat[lo[k]][lo[CurrentIdx]];
	    
	    t = lo[CurrentIdx];
	    for ( k = CurrentIdx - 1; k >= j; k-- )
		lo[k+1] = lo[k];
	    lo[j] = t;
	} else {
	    for (g = 0, k = CurrentIdx+1; k <= j; k++)
		g += CostMat[lo[k]][lo[CurrentIdx]] - 
		    CostMat[lo[CurrentIdx]][lo[k]];
	    t = lo[CurrentIdx];
	    for ( k = CurrentIdx + 1; k <= j; k++ )
		lo[k-1] = lo[k];
	    lo[j] = t;
	}

	ret.i_fitness = ret.i_fitness + g;
	
	if (!create) ind->i_fitness += g;

    }

    return(ret);
}

individual_t mutateIndividual(individual_t *ind, int create) {
    switch (MutationType) {
	case 'i': return(mutateByInsert(ind, create));
	case 'x': return(mutateByInterchange(ind, create));
	default: fatal("Type of Mutation uknown");
	exit(-1); // does not reach this
    }
}

void doMutations(int nmutations) {
    int i, j;
    individual_t o;

    /*puts("MUT:-----------");*/
    for (i = 0; i < nmutations; i++ ) {
	
	j = rand0N(Population->p_size+Offsprings->p_size-nmutations);
	/*printf("I: %d (%d)\nIndivid:  ", i, j); */
	if ( j < Population->p_size ) {
	    /* printFenotype(Population->p_pop[j].i_fenotype, FenotypeLength);*/
	    o = mutateIndividual(&(Population->p_pop[j]), TRUE);
	} else {
	    j -= Population->p_size;
	    /* printFenotype(Offsprings->p_pop[j].i_fenotype, FenotypeLength);*/
	    o = mutateIndividual(&(Offsprings->p_pop[j]), TRUE);
	}
	localSearch(o.i_fenotype, &(o.i_fitness));
	insertIndividual(Offsprings, o.i_fenotype, o.i_fitness);
    } 
}

void doDiversification(){
    int i, j, inserted;
    long int *r;
    long long int c;
    individual_t o;
    population_t ptmp;

    insertIndividual(PopTmp, Population->p_pop[0].i_fenotype, Population->p_pop[0].i_fitness);
    inserted = 1;

    if ( DiversificationType == 'w' ) {
	/* Diversification by Mutation */
	for ( i = 1; i < Population->p_size; i++ ) {
	    o = mutateIndividual(&(Population->p_pop[i]), FALSE);
	    localSearch(o.i_fenotype, &(o.i_fitness));
	    for (j = 0; 
		 (j < inserted) && 
		     ( (o.i_fitness != PopTmp->p_pop[j].i_fitness) ||
		       !equalFenotype(o.i_fenotype, 
				      PopTmp->p_pop[j].i_fenotype, 
				      FenotypeLength) ); 
		 j++);
	    if ( j < inserted ) {
		free(o.i_fenotype);
	    } else {
		inserted++;
		insertIndividual(PopTmp, o.i_fenotype, o.i_fitness);
	    }
	}
    }
    
    for (; inserted < Population->p_size;) { /* increase i only when an individual is inserted */
	r = generate_random_vector(FenotypeLength);
	c = computeCost(r);
	localSearch(r, &c);
	for (j = 0; 
	     (j < inserted) && 
		 ( (c != PopTmp->p_pop[j].i_fitness) ||
		   !equalFenotype(r, PopTmp->p_pop[j].i_fenotype, FenotypeLength) ); 
	     j++);
	if ( j < inserted ) {
	    free(r);
	} else {
	    inserted++;
	    insertIndividual(PopTmp, r, c);
	}
    }

    /* Now PopTmp contain the selected new population */
    ptmp = *PopTmp;
    *PopTmp = *Population;
    *Population = ptmp;
    PopTmp->p_pop[0].i_fenotype = NULL;
    resetPopulation(PopTmp,TRUE);
    /*
    inserted = 0;
    for (j = 0; j < Population->p_size; j++) 
	for (i = j+1; i < Population->p_size; i++) 
	    if ( equalFenotype(Population->p_pop[i].i_fenotype,
			       Population->p_pop[j].i_fenotype, FenotypeLength) ) 
		inserted++;
    printf("AFTER DIVERSIFICATION Population [%d]!\n", inserted); 
    if (inserted > 0 ) exit(-1); */

}

long long int bestFitness() {
    return(Population->p_pop[0].i_fitness);
}

long long int worstFitness() {
    return(WorstFitness);
}


long int *bestFenotype() {
    return(Population->p_pop[0].i_fenotype);
}

int convergedPopulation() {
    static double avg = 0; 
    static int notchanging = 0;
    double newavg;
    double t;
    int re, i;
    
    for (t = 0, i = 0; i < Population->p_size; t += Population->p_pop[i++].i_fitness){
	/*intentionally blank*/
    }
    
    newavg = t / (double) Population->p_size;
    

    if ( fabs(avg-newavg) < 0.000001 ){ 
	notchanging++;
    }  else {
	avg = newavg;
    }
    
    re = (notchanging > MaxGenNCAvg);
    if ( re ){
	notchanging = 0;
    }
    return(re);
}
