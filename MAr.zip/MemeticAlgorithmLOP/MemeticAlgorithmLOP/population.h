/*    
    MALOP Memetic Algorithm for Linear Ordering Problem
    Copyright (C) 2004  Tommaso Schiavinotto (tommaso.schiavinotto@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _POPULATION_H_
#define _POPULATION_H_

#define MAXGEN_NOT_CHANGING_AVERAGE ( 30 )

typedef struct _individual_t {
    long long int i_fitness;
    long int *i_fenotype;
} individual_t;

typedef struct _population_t {
    int p_size;
    individual_t *p_pop;
} population_t;


void initializePopStructs(int fenlen, int size, int ncrossover, int nmutations, int mnc);
void generateIndividuals();
void selectPopulation();
void doCrossovers(int ncrossover);
void doMutations(int nmutations);
void doDiversification();
void commitGenocide();
int convergedPopulation();
long long int bestFitness();
long int *bestFenotype();
void printPopulation();

extern int MutationsRepeat;
extern int MaxMutLength;
extern int MutationType;
extern int CrossoverType;
extern int MaxGenNCAvg;
extern int DiversificationType;

#endif
