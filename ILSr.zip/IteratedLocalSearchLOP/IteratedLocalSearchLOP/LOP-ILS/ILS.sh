#!/bin/bash

#########################################
## Parametros que le pasamos al script ##
#########################################
# $1 el fichero del problema que se quiere ejecutar el EDA.
# $2 el nombre del tipo de EDA que ejecutaremos: UMDA, EBNA, TREE
#########################################

#$ -S /bin/bash
#
#######################################
# Usar el directorio de trabajo actual
#######################################
#$ -cwd

# Tiempo de trabajo

# juntar la salida estandar y de error en un solo fichero
#$ -j y
###########################
# usar colas indicadas
#j##########################

#$ -q all.q@nodo70,all.q@nodo71,all.q@nodo72,all.q@nodo73,all.q@nodo74,all.q@nodo75,all.q@nodo76
#$ -t 1-20:1
#$ -l vf=0.7G
#$ -o /dev/null
#################################
#Nuestro directorio de scratch
##################################
# scratch en kalimero, i2Bask y ATC

#Para que me ponga ejecutables de distintos problemas en distintos directorios
scrt=/var/tmp/$USER/$JOB_ID-$SGE_TASK_ID
#scrt=/home/jceberio001/$USER/$JOB_ID-$SGE_TASK_ID
# scratch en pendulo
# scrt=/scratch/$USER/$JOB_ID

#crear directorio scratch
#echo "mkdir -p $scrt"
mkdir -p $scrt

##########################################################################################
#creamos los subdirectorios donde queremos guardar los resultados (si no estan creados)
##########################################################################################
#mkdir -p $SGE_O_WORKDIR/results

#######################################################
#Copiamos los archivos al directorio scratch.
#Usaremos cp -r para copiar tambien subdirectorios.
#Se puede pasar un tercer parametro en el que indicar
#ficheros adicionales a copiar
#######################################################

# Parámetros del script. Únicamente 2:
# $1-> algoritmo de ejecución. UMDA, MIMIC, EBNA o TREE
# $2-> tipo de problema. tsp, qap, fsp o lop

# Direccionamiento absoluto y relativo
echo "Loading execution files..."
Code_Directory="/home/jceberio001/ExperimentUbiquity/Time_20s/ILS/code/"
Instance_Path=$2
Instance_File=${Instance_Path##*/}

Results_Directory="/home/jceberio001/ExperimentUbiquity/Time_20s/ILS/results/"

# Mover ficheros necesarios al $scrt
cp $Instance_Path $scrt
cp $Code_Directory/ils_lop $scrt

# Nos movemos de directorio
cd $scrt

#########################
#Ejecutamos el programa
#########################
# echo Host --> $HOSTNAME
echo Init Time: `date`

# Para la semilla
((sem=$SGE_TASK_ID*10))

# sleep $SGE_TASK_ID

# INITIALIZE PARAMETER
output_file_name="ILS.$Instance_File-$SGE_TASK_ID.dat"
# Run program
echo $scrt

echo "Running..."
./ils_lop -o $output_file_name  -i $Instance_File -s $sem -u $3 -n 1 -t 20

# Guardar resultados
mv $scrt/$output_file_name $Results_Directory

rm -rf $scrt
echo End  Time: `date`

